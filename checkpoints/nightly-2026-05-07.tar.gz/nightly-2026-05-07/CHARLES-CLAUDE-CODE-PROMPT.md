# Charles — Custom Python Agent · Initial Build Prompt for Claude Code

Paste this whole document as the first message in a fresh Claude Code session, started with `claude` from `~/charles/` (create the directory first: `mkdir ~/charles && cd ~/charles`).

---

## Mission

You're building Charles, a custom Python autonomous AI agent for Johnathon Keith on a Mac Studio M1 Ultra (64GB). This is a fresh codebase replacing a failed OpenClaw deployment that couldn't deliver fast multi-tool agentic operation on consumer hardware.

The high-level vision (from Johnathon's "Mac Migration Checklist"):

- Fully autonomous agent — runs an event loop, doesn't just react
- Self-modifying — Charles can read and edit his own Python source over time
- Tool-using — shell, filesystem, web, browser automation, voice (Whisper), eventually iMessage
- Multi-channel — primary channel is Telegram; iMessage and others come later
- Persistent identity & memory — Charles develops his own personality, keeps daily logs, curates long-term memory
- Eventual job: helps with construction-industry projects (ContractorPro), research, email/calendar management, and his own continued evolution

Johnathon is a construction-industry pro who's been ramping into AI for ~3 months. Plain communication, no patronizing, technical depth is welcome.

## Why not OpenClaw / Letta / etc.

OpenClaw injects every registered tool's full JSON schema into every prompt. With ~26 tools, that's 33k+ characters of tool schemas per request, plus auto-injected workspace boilerplate. Total prompt ~21k tokens per message. At Apple Silicon's prompt-eval rate of ~100 tok/s, that's 2+ minutes per response — fundamentally incompatible with fast autonomous loops.

**The architectural fix custom Python provides: dynamic tool loading.** Only ship 2-3 tool schemas per turn, decided by a classifier (start simple: keyword match; later: a tiny 1B model). Lean base prompt, big effective tool surface, fast turn time.

## Hardware & infra already in place

- macOS, Mac Studio M1 Ultra, 64GB unified memory
- Python 3.11 at `/opt/homebrew/bin/python3.11`
- **MLX-LM server** running as launchd service at `http://127.0.0.1:8080/v1`:
  - Model: `mlx-community/Qwen3.6-35B-A3B-4bit`
  - OpenAI-compatible chat-completions API
  - **IMPORTANT:** Model has thinking mode ON by default. You must disable it via `enable_thinking=False` in the chat template, OR by stripping `<think>...</think>` tags from responses before returning them. Test both approaches in Milestone 0.
  - **IMPORTANT:** Tool-call output format is non-standard. Qwen3.6 emits Hermes-style XML inside `<tool_call>` tags: `<function=name><parameter=key>value</parameter></function>` rather than standard JSON. Test the actual model output before designing the tool-call parser.
- **Telegram bot**: `@SuperCharlesAI_bot`. Owner-only access — owner Telegram user ID is `8455750177` (phone +1 615-663-7932). Token will be in env var `TELEGRAM_BOT_TOKEN` (Johnathon will set it).
- **iMessage**: Messages.app is signed in. Channel comes later.

## Proposed file structure (refine if you have a better idea)

```
~/charles/
├── charles.py            # Entry point: starts event loop + channels
├── core/
│   ├── __init__.py
│   ├── inference.py      # MLX-LM client (OpenAI SDK against 127.0.0.1:8080)
│   ├── agent.py          # Single-turn reasoning + tool dispatch
│   ├── tools.py          # Tool registry, @tool decorator, dynamic loading
│   ├── memory.py         # SQLite-backed structured memory
│   └── prompts.py        # System prompt builder (KEEP LEAN)
├── tools/                # One file per tool
│   ├── __init__.py
│   ├── shell.py          # exec shell commands
│   ├── filesystem.py     # read/write/edit files
│   ├── web.py            # web_search, web_fetch
│   └── self_modify.py    # Charles edits his own .py source
├── channels/
│   ├── __init__.py
│   ├── telegram.py       # python-telegram-bot integration
│   └── imessage.py       # later, after Telegram is solid
├── workspace/            # Charles's writable area
│   ├── SOUL.md          # Empty initially — Charles writes this himself
│   ├── IDENTITY.md      # Same — self-authored
│   ├── memory.db        # SQLite (created at runtime)
│   ├── memory/          # Daily markdown logs
│   └── projects/        # Working files
├── config.py
├── requirements.txt
├── .env.example
├── .gitignore
└── README.md
```

## Design principles (do not violate without explicit user OK)

1. **Lean default prompt.** Base system prompt target: ~500 tokens. Includes identity (read from `workspace/SOUL.md` if present, else minimal default), tool *summaries* (one line per tool, NOT full schemas), recent context. Per-turn total target: under 3k tokens. Print the char count every turn during dev to catch bloat.

2. **Dynamic tool loading.** When the agent decides to use tools, only inject the FULL schemas for the 2-3 tools the current turn actually needs. The classifier in `core/tools.py` decides which tools to load. v0: simple keyword matching against tool names + descriptions. v1+: small classifier model (later; not Milestone 0).

3. **Tool definition pattern:** Python decorator-based registry.
   ```python
   from core.tools import tool

   @tool(
       name="exec",
       summary="Run a shell command and return stdout/stderr.",
       schema={
           "type": "object",
           "properties": {"command": {"type": "string", "description": "Shell command"}},
           "required": ["command"],
       },
   )
   def exec_command(command: str) -> str:
       ...
   ```
   The `@tool` decorator registers full schema, summary, and handler in the central registry.

4. **Memory architecture.** SQLite at `~/charles/workspace/memory.db`. Tables: `conversations`, `daily_log`, `long_term_facts`. Memory is QUERIED into prompts on demand, NOT dumped wholesale every turn.

5. **Self-modification.** A `self_modify` tool lets Charles propose changes to his own `.py` files. v0: it just writes the file (with backup). v1+: a one-step review where Charles re-reads his proposed change before commit. v2+: Charles can author entirely new tools and add them to `tools/`. Build with this growth path in mind.

6. **Channels are dumb pipes.** Telegram channel layer receives a message, calls `core.agent.respond(message, conversation_id)`, ships the response back. NO agent reasoning in channel code. This makes adding channels trivial.

7. **Event loop is the heart.** `charles.py` should be:
   ```python
   while True:
       process_inbound_messages()    # all channels
       run_scheduled_tasks()          # cron-style + agent-decided
       sleep(adaptive_delay)          # tighter when active, looser at night
   ```

8. **Minimal dependencies.** `openai` SDK (for MLX-LM client), `python-telegram-bot`, `python-dotenv`, stdlib `sqlite3`. NO LangChain, LangGraph, LiteLLM, AutoGen, CrewAI. The whole point is owning the agent logic.

## Build plan

### Milestone 0 — "Charles says hi"

Goal: end-to-end smoke test, no tools.

Deliverables:
- Project skeleton (dirs above, empty `__init__.py`s, `requirements.txt`, `.env.example`, `.gitignore`, `README.md`)
- `config.py` — loads env vars (`TELEGRAM_BOT_TOKEN`, `MLX_BASE_URL` defaulting to `http://127.0.0.1:8080/v1`, `OWNER_TELEGRAM_ID=8455750177`)
- `core/inference.py` — minimal MLX-LM client using `openai` SDK, disables thinking, returns plain text
- `core/agent.py` — `respond(message: str) -> str`. Lean ~500-token system prompt, no tools, just text response
- `channels/telegram.py` — receives owner-only messages, calls `agent.respond`, sends reply back
- `charles.py` — entrypoint that starts Telegram channel and blocks

Acceptance criteria:
- `python3.11 charles.py` starts cleanly
- Send "hi" from Johnathon's phone to `@SuperCharlesAI_bot`
- Charles responds with sensible text in under 10 seconds
- No `<think>` tags or formatting artifacts in the response
- Print the prompt char count to console for visibility

### Milestone 1 — Tool registry + first 3 tools

After Milestone 0 is proven:
- `core/tools.py` with `@tool` decorator and registry
- Three tools: `read_file`, `write_file`, `exec_shell`
- Dynamic loading: classifier (keyword match) decides which tool schemas to inject per turn
- Test: ask Charles to "list the files in /tmp" — he should call `exec_shell` cleanly

### Milestone 2 — Memory

SQLite-backed conversations + daily logs. Charles can `remember(fact)` and `recall(query)`.

### Milestone 3 — Self-modification

`self_modify` tool. Charles can edit his own `.py` files (with backup). Test: ask Charles to add a comment to one of his own functions.

### Milestone 4 — Event loop + scheduled tasks

`charles.py` becomes the autonomous loop. Charles can register tasks ("check email every 5 min") that he handles himself.

### Milestone 5+ — More channels, more tools, real work

iMessage, Whisper voice, Playwright, sentiment analysis, ContractorPro work, etc.

## Process

1. **Before writing any code: read this whole document.** Ask any clarifying questions. Don't assume.
2. **Plan Milestone 0** explicitly before coding it. Show the file tree you'll create and key snippets.
3. **Build Milestone 0.** Get user confirmation it works before moving on.
4. **Iterate.** Each milestone is small, testable, demonstrable.

## A few things you should know

- The user has spent the last 24+ hours debugging OpenClaw. He's tired and a bit raw on the topic. Don't lecture. Be direct, technical, and respectful.
- The user is hands-on with Terminal but new to the broader Mac/Python ecosystem (came from Windows ~3 weeks ago). Explain Mac-specific things (launchd, brew, hidden folders) when relevant.
- "YOLO / God Mode" in the original migration checklist maps to: shell access with no permission gates, no sandboxing, full filesystem access. Don't add safety prompts that break the autonomy goal. Charles should be able to run commands without asking. Trust the user to wield the gun he asked for.
- Self-modification is a feature, not a risk to mitigate. Charles editing his own code is the goal, not the threat.
- Migration checklist reference: there's a copy at `~/Desktop/MAC_MIGRATION_CHECKLIST.md` — read it for full context.

## Final note

We're building Charles's foundation. Get it right. Speed of build doesn't matter as much as cleanliness of architecture — Charles will live in this code and edit it himself for years if it's good.
